import java.util.ArrayList;
import java.util.concurrent.*;

public class MainThreadPool2a {
    public static void main(String[] args) {

        ArrayList<ThreadPoolTask2a> bundle = new ArrayList<ThreadPoolTask2a>();

        double startTime = System.nanoTime();
        ExecutorService pool = Executors.newFixedThreadPool(100);
        for (int i = 0; i < 100000; i++) {
            String mainThreadName = "Thread " + i;
            ThreadPoolTask2a parentThread = new ThreadPoolTask2a(mainThreadName);
            bundle.add(parentThread);
        }
        for (int j = bundle.size()-1; j > 0; j--) {
            pool.execute(bundle.get(j));
        }
        pool.shutdown();
        if (!pool.isTerminated()) {
            try {
            pool.awaitTermination(1, TimeUnit.SECONDS);
            pool.shutdown();
            } catch (InterruptedException e) {
                System.out.println("exception awaiting termination");
            }
        }
        System.out.println("Pool Is Terminated " + pool.isTerminated());

        double endTime = System.nanoTime();

        double duration = (endTime - startTime);
        System.out.println("Start time: " + (startTime/1000000) + " Mili-seconds");
        System.out.println("End time: " + (endTime/1000000) + " Mili-seconds");
        System.out.println("Duration: " + (duration/1000000) + " Mili-seconds");
    }
}