import java.util.*;

public class Main2a {
	
	public static void main(String[] args) {
		int mainThreadCreated = 0;
		int mainThreadDestroyed = 0;
		ArrayList<Thread2a> bundle = new ArrayList<Thread2a>();

		//For question 2a
		double startTime = System.nanoTime();
		for (int i = 0; i < 100000; i++) {
			String num_thread = "Thread-" + i;
			Thread2a thread_obj = new Thread2a(num_thread);
			bundle.add(thread_obj);
			mainThreadCreated++;
		}

		for (int j = bundle.size()-1; j >= 0; j--) {
			bundle.get(j).start();
			try{
				bundle.get(j).join();
			} catch (InterruptedException e) {
				System.out.println("The Main thread is interrupted.");
			}
			mainThreadDestroyed++;
		}
		double endTime = System.nanoTime();

		double duration = (endTime - startTime);
		System.out.println();
		System.out.println("Start time: " + (startTime/1000000) + " Mili-seconds");
		System.out.println("End time: " + (endTime/1000000) + " Mili-seconds");
		System.out.println("Duration: " + (duration/1000000) + " Mili-seconds");
		System.out.println("Main Threads Created: " + mainThreadCreated);
		System.out.println("Main Threads Destroyed: " + mainThreadDestroyed);
	}
}




