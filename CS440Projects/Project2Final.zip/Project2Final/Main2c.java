import java.util.ArrayList;

public class Main2c {
    public static void main(String[] args) {
        int mainThreadCreated=0;
        int mainThreadDestroyed=0;
        ArrayList<Thread2c> bundle = new ArrayList<Thread2c>();

        // For question 2c

        int childThreadCreated = 0;
        int childThreadDestroyed = 0;
        int grandchildThreadCreated = 0;
        int grandchildThreadDestroyed = 0;

        double startTime = System.nanoTime();
        for (int i=0; i<10;i++) {
            String mainThreadName = "Mom Thread " + i;
            System.out.println(mainThreadName);
            Thread2c parentThread = new Thread2c(mainThreadName);
            bundle.add(parentThread);
            childThreadCreated += parentThread.getChildThreadCreated();
            grandchildThreadCreated += parentThread.getGrandchildThreadCreated();
            mainThreadCreated++;

            System.out.println();
        }

        for (int j = bundle.size()-1; j >= 0; j--) {
            try{
                bundle.get(j).startGrandchildren();
                grandchildThreadDestroyed += bundle.get(j).getGrandchildThreadDestroyed();
                bundle.get(j).join();
            } catch (InterruptedException e) {
                System.out.println("The Main thread is interrupted.");
            }
            bundle.get(j).clearGrandchildBundle();
        }

        for (int j = bundle.size()-1; j >= 0; j--) {
            try{
                bundle.get(j).startChildren();
                childThreadDestroyed += bundle.get(j).getChildThreadDestroyed();
                bundle.get(j).clearChildBundle();
                bundle.get(j).sleep(0);
                bundle.get(j).start();
                bundle.get(j).join();
            } catch (InterruptedException e) {
                System.out.println("The Main thread is interrupted.");
            }
            mainThreadDestroyed++;
        }
        double endTime = System.nanoTime();

        double duration = (endTime - startTime);
        System.out.println();
        System.out.println("Start time: " + (startTime/1000000) + " Mili-seconds");
        System.out.println("End time: " + (endTime/1000000) + " Mili-seconds");
        System.out.println("Duration: " + (duration/1000000) + " Mili-seconds");
        System.out.println("Parent Threads Created: " + mainThreadCreated);
        System.out.println("Parent Threads Destroyed: " + mainThreadDestroyed);
        System.out.println("Total Children Threads Created: " + childThreadCreated);
        System.out.println("Total Children Threads Destroyed: " + childThreadDestroyed);
        System.out.println("Total Grandchildren Threads Created: " + grandchildThreadCreated);
        System.out.println("Total Grandchildren Threads Destroyed: " + grandchildThreadDestroyed);
        System.out.println("Total Threads Created: " + (mainThreadCreated+childThreadCreated+grandchildThreadCreated));
        System.out.println("Total Threads Created: " + (mainThreadDestroyed+childThreadDestroyed+grandchildThreadDestroyed));
    }
}
