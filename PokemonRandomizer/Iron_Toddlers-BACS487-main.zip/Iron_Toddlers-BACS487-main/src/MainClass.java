
public class MainClass{

	public static void main(String[] args) {
		try {
			Randomizer window = new Randomizer();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
