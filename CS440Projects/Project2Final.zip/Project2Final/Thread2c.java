import java.util.ArrayList;

public class Thread2c extends Thread {
    Thread t;
    Thread granChild;
    String threadName;
    int childThreadCreated;
    int childThreadDestroyed;
    int grandchildThreadCreated;
    int grandchildThreadDestroyed;
    ArrayList<Thread> childBundle = new ArrayList<Thread>();
    ArrayList<Thread> grandchildBundle = new ArrayList<Thread>();

    Thread2c(String threadName) {
        this.threadName = threadName;
        this.childThreadCreated = 0;
        this.childThreadDestroyed = 0;
        this.grandchildThreadCreated = grandchildThreadCreated;
        this.grandchildThreadDestroyed = grandchildThreadDestroyed;
        this.setName(this.threadName);

        for (int i=0; i<100; i++) {
            t = new Thread(this, "Child Thread "+i);
            System.out.println("Creating Child: " + t.getName() + " Belongs to " + this.threadName);
            childBundle.add(t);
            this.childThreadCreated++;

            for (int j = 0; j<100; j++) {
                granChild = new Thread(this, "Grandchild Thread "+j);
                System.out.println("Creating Grandchild: " + granChild.getName() + " Belongs to " + t.getName() + " Has Parent " + this.threadName);
                grandchildBundle.add(granChild);
                this.grandchildThreadCreated++;
                try {
                    granChild.join();
                } catch (InterruptedException e) {
                    System.out.println("The child thread is interrupted.");
                }
            }
            try{
                t.join();
            } catch (InterruptedException e) {
                System.out.println("The child thread is interrupted.");
            }
        }

    }

    @Override
    public void run() {
        try {
            t.sleep(0);
        } catch (InterruptedException e) {
            System.out.println("The child thread is interrupted.");
        }

        if(this.grandchildBundle.isEmpty()&& !this.childBundle.isEmpty()) {
            System.out.println("Destroying the " + Thread.currentThread().getName() + " Whose Mom is "+ this.threadName);
        }

        if ( this.grandchildBundle.isEmpty() && this.childBundle.isEmpty()) {
            System.out.println("Destroying " + this.threadName);
        }

        if(!this.grandchildBundle.isEmpty() && !this.childBundle.isEmpty()){
            System.out.println("Destroying " + Thread.currentThread().getName() + " Whose Parent is " + t.getName() +
                    " Whose Grandparent is " + this.threadName);
        }
    }

    public void startChildren() {
        for (int j = childBundle.size()-1; j >= 0; j--) {
            try{
                childBundle.get(j).start();
                childBundle.get(j).join();
            } catch (InterruptedException e) {
                System.out.println("The Main thread is interrupted.");
            }
            this.childThreadDestroyed++;
        }
    }

    public void startGrandchildren() {
        for (int j = grandchildBundle.size()-1; j >= 0; j--) {
            try{
                grandchildBundle.get(j).start();
                grandchildBundle.get(j).join();
            } catch (InterruptedException e) {
                System.out.println("The Main thread is interrupted.");
            }
            this.grandchildThreadDestroyed++;
        }
    }

    public int getChildThreadCreated() {
        return this.childThreadCreated;
    }

    public int getChildThreadDestroyed() {
        return this.childThreadDestroyed;
    }

    public int getGrandchildThreadCreated() {
        return this.grandchildThreadCreated;
    }

    public int getGrandchildThreadDestroyed() {
        return this.grandchildThreadDestroyed;
    }

    public void clearChildBundle() {
        this.childBundle.clear();
    }

    public void clearGrandchildBundle() {
        this.grandchildBundle.clear();
    }

}
