import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MainThreadPool2b {
    public static void main(String[] args) {

        ArrayList<ThreadPoolTask2b> bundle = new ArrayList<ThreadPoolTask2b>();

        double startTime = System.nanoTime();
        ExecutorService pool = Executors.newFixedThreadPool(100);
        for (int i = 0; i < 100; i++) {
            String mainThreadName = "Thread " + i;
            ThreadPoolTask2b parentThread = new ThreadPoolTask2b(mainThreadName);
            bundle.add(parentThread);
        }

        for (int j = bundle.size()-1; j >= 0; j--) {
            int index = j;
            pool.execute( () -> {
                bundle.get(index).startChildren();
                String message = bundle.get(index).getName() + " Destroyed";
                System.out.println(message);
            });
        }
        pool.shutdown();
        if (!pool.isTerminated()) {
            try {
                pool.awaitTermination(10, TimeUnit.SECONDS);
                pool.shutdown();
            } catch (InterruptedException e) {
                System.out.println("exception awaiting termination");
            }
        }
        System.out.println("Pool Is Terminated " + pool.isTerminated());



        double endTime = System.nanoTime();

        double duration = (endTime - startTime);
        System.out.println("Start time: " + (startTime/1000000) + " Mili-seconds");
        System.out.println("End time: " + (endTime/1000000) + " Mili-seconds");
        System.out.println("Duration: " + (duration/1000000) + " Mili-seconds");
    }
}


