import java.util.ArrayList;

public class Main2b {
    public static void main(String[] args) {
        int mainThreadCreated=0;
        int mainThreadDestroyed=0;
        ArrayList<Thread2b> bundle = new ArrayList<Thread2b>();

        // For question 2b
        double startTime = System.nanoTime();
        int childThreadCreated = 0;
        int childThreadDestroyed = 0;

        for (int i=0; i<100;i++) {
            String mainThreadName = "Mom Thread " + i;
            System.out.println(mainThreadName);
            Thread2b parentThread = new Thread2b(mainThreadName);
            bundle.add(parentThread);
            childThreadCreated += parentThread.getChildThreadCreated();
            mainThreadCreated++;

            System.out.println();
        }

        for (int j = bundle.size()-1; j >= 0; j--) {
            try{
                bundle.get(j).startChildren();
                childThreadDestroyed += bundle.get(j).getChildThreadDestroyed();
                bundle.get(j).start();
                bundle.get(j).join();
            } catch (InterruptedException e) {
                System.out.println("The Main thread is interrupted.");
            }
            mainThreadDestroyed++;
        }
        double endTime = System.nanoTime();

        double duration = (endTime - startTime);
        System.out.println();
        System.out.println("Start time: " + (startTime/1000000) + " Mili-seconds");
        System.out.println("End time: " + (endTime/1000000) + " Mili-seconds");
        System.out.println("Duration: " + (duration/1000000) + " Mili-seconds");
        System.out.println("Parent Threads Created: " + mainThreadCreated);
        System.out.println("Parent Threads Destroyed: " + mainThreadDestroyed);
        System.out.println("Total Children Threads Created: " + childThreadCreated);
        System.out.println("Total Children Threads Destroyed: " + childThreadDestroyed);

    }
}
