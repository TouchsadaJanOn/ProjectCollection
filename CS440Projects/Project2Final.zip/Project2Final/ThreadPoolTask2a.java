public class ThreadPoolTask2a extends Thread{
    private Thread t;
    private String threadName;


    ThreadPoolTask2a(String name) {
        this.threadName = name;
        this.setName(threadName);
        System.out.println("Creating " +  this.threadName );
    }

    @Override
    public void run() {
//		System.out.println("Running " +  threadName );

        try {
            this.sleep(0);
        } catch (InterruptedException e) {
            System.out.println("Thread " +  Thread.currentThread().getName() + " interrupted.");
        }
        System.out.println("Destroying " +  this.threadName);
    }

}