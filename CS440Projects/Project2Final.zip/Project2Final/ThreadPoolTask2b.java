import java.util.ArrayList;
import java.util.concurrent.*;

public class ThreadPoolTask2b extends Thread {
    Thread t;
    String threadName;
    int childThreadCreated;
    int childThreadDestroyed;
    ArrayList<Thread> childBundle = new ArrayList<Thread>();

    ThreadPoolTask2b(String threadName) {
        this.threadName = threadName;
        this.childThreadCreated = 0;
        this.childThreadDestroyed = 0;
        this.setName(this.threadName);

        for (int i=0; i<1000; i++) {
            t = new Thread(this, "Child Thread " + i);
            childBundle.add(t);
            System.out.println("Creating Child: " + t.getName() + " Belongs to " + this.threadName);
            this.childThreadCreated++;
        }

    }

    @Override
    public void run() {
        try {
            Thread.currentThread().sleep(0);
        } catch (InterruptedException e) {
            System.out.println("The child thread is interrupted.");
        }

        if(this.isAlive())
        {

        } else {
            System.out.println("Destroying the child " + Thread.currentThread().getName() + " Whose Mom is "+ this.threadName);
        }


    }

    public void startChildren() {
        for (int j = childBundle.size()-1; j >= 0; j--) {
            try{
                childBundle.get(j).start();
                childBundle.get(j).join();
            } catch (InterruptedException e) {
                System.out.println("The Main thread is interrupted.");
            }
            childThreadDestroyed++;
//            System.out.println("Is Alive "+ childBundle.get(j).getName()+ " "+ childBundle.get(j).isAlive());
        }
    }

    public ArrayList<Thread> getChildBundle (){
        return childBundle;
    }

    public int getChildThreadCreated() {
        return this.childThreadCreated;
    }

    public int getChildThreadDestroyed() {
        return this.childThreadDestroyed;
    }

}
